// import logo from './logo.svg';
import { Form } from 'react-router-dom';
import './App.css';
import RegisterForm from './compoent/REGISTERFORM';
import Movie from './compoent/Movie';
// import Populardes from './compoent/popd';
// import AddMovie from './compoent/AddMovien
// import Movie from './compoent/Movie';
// import { MovieContext, MovieProvider } from './compoent/MovieContext';
// import MovieList from './compoent/MovieList';
import Nav from './compoent/Nav';
import Forms from './compoent/project';
// import Populardes from './compoent/popd';

function App() {
  return (

    <div className='App'>
      {/* <Nav/> */}
      {/* <Populardes/> */}
      <RegisterForm/>
      {/* <Movie/>
       */}
     
  
    </div>
  
  );
}

export default App;
