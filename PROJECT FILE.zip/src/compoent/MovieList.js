import React, { useState, useContext } from "react";
import Movie from "./Movie";
import { MovieContext } from "./MovieContext";

const MovieList = () => {
  const [movies, setMovies] = useContext(MovieContext);
  return (
    <div>
      {movies.map((movie) => (
        <Movie name={movie.name} price={movie.price} key={movie.id} />
      ))}
      <a href='http://localhost:8000/api?issuer=ideal_KNABNL2H'>Go to Pay</a> 
<button onclick="window.location.href='http://www.google.com'"></button>
    </div>
  );
};

export default MovieList;