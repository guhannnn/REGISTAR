import React, { Component } from "react";
import './popd.css';
class Populardes extends React.Component{
  render(){
      return (
        <div>
          <title>TravCom - Destinations</title>
          <header className="nav-header">
            <div className="nav-title">
              <a href="./home.html">TravCom</a>
            </div>
            <input type="checkbox" id="nav-check" />
            <div className="nav-btn">
              <label htmlFor="nav-check">
                <span />
                <span />
                <span />
              </label>
            </div>
            <nav className="nav-links" aria-label="Navigation links in TravCom header">
              <ul>
                <li className="navItems"><a href="./home.html">HOME</a></li>
                <li className="navItems"><a href="./popular-destinations.html">POPULAR DESTINATIONS</a></li>
                <li className="navItems"><a href="./enquire-us.html">ENQUIRE US</a></li>
                <li className="navItems"><a href="./gallery.html">GALLERY</a></li>
                <li className="navItems">
                  <label className="navItems">search</label>
                  <input type="search" />
                </li>
              </ul>
            </nav>
          </header>
          <main>
            <div className="destination-cardHolder">
              <table className="destination-cardTable">
                <tbody>
                  <tr>
                    <td className="coim d-card" onClick={() => window.open( 'https://www.google.com/maps/place/Mahabalipuram,+Tamil+Nadu+603104/@12.6223265,80.1736327,14z/data=!3m1!4b1!4m5!3m4!1s0x3a5254aa30074dc5:0x9d00999d9ca8933f!8m2!3d12.6207821!4d80.1944915')}>
                      <a href="./cbe/cbe.html">Coimbatore</a>
                    </td>
                    <td className="chenn d-card">
                      <a href="./chennai/chennai.html">Chennai</a>
                    </td>
                    <td className="kky d-card">
                      <a href="./kk/kk.html">Kanniyakumari</a>
                    </td>
                  </tr>
                  <tr>
                    <td className="tan d-card">
                      <a href="./tanjore/tanjore.html">Tanjore</a>
                    </td>
                    <td className="oo d-card">
                      <a href="./ooty/ooty.html">Ooty</a>
                    </td>
                    <td className="mad d-card">
                    <button onClick={() => window.open( 'http://www.google.com')} >madurai</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </main>
        </div>
      );
  }
}
  

  export default Populardes;