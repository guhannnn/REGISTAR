import React from "react";
import { Form } from "react-router-dom";
class Forms extends React.Component
{
    render() {
        return (
        <div id="registration">
         <div id="register">
            <h3>User Registration</h3>
            <form   name="RegistrationForm"  >
            <label>Name</label>
            <input type="text" name="username" placeholder="your Username" required/>
           <br></br>
           <br></br>
            <label>Email ID:</label>
            <input type="email" name="emailid" placeholder="your email" required />
            <br></br>
            <br></br>
            
           <br></br>
            <label>Password</label>
            <input type="password" name="password" placeholder="your password" required />
            <br></br>
<br></br>
            <label >submit</label>
            <button type="submit" name="submit"></button>
            
            </form>
        </div>
      </div>
     );
    }
}

export default Forms;